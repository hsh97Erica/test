public class Stack {       
    private Node top; 
    private int size;
    private class Node {
        int data;
        Node next;
        Node(int data){
        	this.data = data;
        }
    }
    
    public Stack() {
        top = null;
    }

    public void push(int data){

    }

    public Node pop(){
    	
    }
   
    public Node top() {

    }
   
    public boolean isEmpty(){

    }

    public void printStack(){

    }


}
