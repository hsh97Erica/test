public class FruitSeller {
	int numOfApple;
	int myMoney;
	int APPLE_PRICE;
	
	public FruitSeller(int num_apple, int money, int apple_price){ //������
	
		//// TODO #1
				
		
		APPLE_PRICE = apple_price;
			
	}
	
	public int saleApple(int money){
		
		//// TODO #2
		// first calculate the number of apples that can buy using money.
		// update member variables
		// and finally return change.
		
		
		return money%APPLE_PRICE; 
				
	}
	
	public void showSaleResult(){
		System.out.println("���� ���(remaining apples) : " + numOfApple);
		System.out.println("���� �ܾ�(current balance) : " + myMoney);
		System.out.println();
	}
	
}