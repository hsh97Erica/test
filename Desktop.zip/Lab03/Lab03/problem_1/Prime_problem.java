package Lab03.problem_1;

import java.util.*;

public class Prime_problem {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int N, count;
		// TODO #1 Generic ArrayList 선언 및 저장
		//ArrayList<Integer> Primes = ...
		System.out.print("Input N : ");
		
		N = s.nextInt(); // 숫자를 입력받는다.
	
		// TODO #2 소수 검사 알고리즘
		for(...) {
			//count = ...;
			
			for(...) {
				// 약수가 있는지 없는지 검사한다
				if(...) {
	
				}
			}
			if(...) {
				// 소수면 Primes에 저장

			}
		}
		for(int i = 0; i < Primes.size(); i++) {
			System.out.print(Primes.get(i)+" "); 
		}
	}
}
