package Lab03.problem_2;

public class FruitSeller {
	private int numOfApple;
	private int myMoney;
	public static int APPLE_PRICE;
	
	public FruitSeller(int num_apple, int money, int apple_price){ //생성자
		//// TODO #1
		APPLE_PRICE = apple_price;
			
	}
	
	public int saleApple(int money){
		//// TODO #2
		// 입력받는 돈으로 Buyer가 살 수 있는 사과의 개수를 구해서 팔고 남은 numOfApple과 myMoney를 업데이트

		// 잔돈을 반환
		return money%APPLE_PRICE; 
				
	}
	
	public void showSaleResult(){
		System.out.println("남은 사과(remaining apples) : " + numOfApple);
		System.out.println("현재 잔액(current balance) : " + myMoney);
		System.out.println();
	}
	
}