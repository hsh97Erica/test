package Lab03.problem_2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FruitSeller seller1 = new FruitSeller(30, 4000, 500);
		///30개 사과랑 4000원 가지고 있고 개당 500원에 사과 팔꺼야
		
		FruitSeller seller2 = new  FruitSeller(50, 10000, 1000);
		///50개 사과랑 10000원 가지고 있고 1000원에 사과 팔꺼야
		
		FruitBuyer buyer = new FruitBuyer(15500, 10);
		///바이어는 20000원이랑 10개 사과 가지고 있어
		
		buyer.buyApple(seller1, 4200);
		/// 1아저씨 사과 4200원어치 주세요 (500원짜리 8개)
		
		buyer.buyApple(seller2, 7300);
		//// 2아저씨 사과 8000원어치 주세요 (1000원짜리 8개)
		
		System.out.println("<과일판매자 1(state of seller1)>"); // 과일판매자 1의 현재상황
		seller1.showSaleResult();
		
		System.out.println("<과일판매자2(state of seller2)>"); // 과일판매자 2의 현재상황
		seller2.showSaleResult();

		System.out.println("<과일구매자(state of buyer)>"); // 과일구매자의 현재상황
		buyer.showBuyResult();

	}
}
