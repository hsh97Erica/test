package Lab03.problem_2;

public class FruitBuyer {

	private int myMoney;
	private int numOfApple;
	
	public FruitBuyer(int money, int apple_num) { //생성자
		// TODO #1
		//생성자는 객체 생성시 넘겨받은 값을 클래스 멤버 변수에 저장합니다.
		
	}
	
	public void buyApple(FruitSeller seller, int money) {
		// TODO #2
		// 구매한 사과 및 잔액을 고려하여 멤버변수를 업데이트
		
		// numOfApple = ...
		// myMoney = ...
	}
	
	public void showBuyResult() {
		System.out.println("현재 잔액(current balance) : " + myMoney);
		System.out.println("현재 사과 개수(current the number of apples) : " + numOfApple);
		System.out.println();
	}
	
	
}
