package Lab03.problem_3;

import java.util.ArrayList;

public class Box<T> {
	//TODO #1
	//private 으로 이름이 t이고 타입이 T인 ArrayList 와 int size를 멤버변수로 선언한다

	public Box() {
		//TODO #2 
		///생성자에서는 멤버변수를 초기화 시킵니다
		
	}
	public void add(T t) {
		// TODO #3
		// 힌트 : 멤버변수로 있는 ArrayList에 넘겨받은 값(T t)을 추가(add 메소드 사용)시킵니다
		// 추가후에는 size를 증가시킵니다.
		
	}
	
	public void remove(T t) {  
		// TODO #4
		// 힌트 : 멤버변수로 있는 ArrayList안에 넘겨 받은 값이 있는지
		// '반복적'으로 확인하여 '없을 때 까지' 값을 지웁니다.
		// 값을 지울때에는 size를 감소시킵니다.
			
		}
	
	public void print() {
		// TODO #5
		// 멤버변수인 ArrayList의 내용과 size 값을 출력합니다
		
	}
	
}
